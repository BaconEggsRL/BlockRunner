package tan.blockrunner;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;

public class Player implements GameObject {
    private Rect rectangle;
    private int color;
    public int vel;

    public Player(Rect rectangle, int color){
        this.rectangle = rectangle;
        this.color = color;
        vel = 0;
    }

    public Rect getRect(){
        return rectangle;
    }

    @Override
    public void draw(Canvas canvas) {
        Paint paint = new Paint();
        paint.setColor(color);
        canvas.drawRect(rectangle,paint);
    }

    public boolean playerCollide(Obstacles o){
        if (rectangle.intersects(rectangle, o.getRect())) {
            //if(rectangle.contains(o.getRect()))
            return true;
        } else {
            return false;
        }
    }

    @Override
    public void update() {

        if(rectangle.bottom+vel <= 500) {
            vel += Constants.ACCEL;
            rectangle.set(rectangle.left, rectangle.top + vel,
                    rectangle.right, rectangle.bottom + vel);
        }
        else{
            vel = Constants.ACCEL;
            rectangle.set(100,400,200,500);
        }
    }
}
