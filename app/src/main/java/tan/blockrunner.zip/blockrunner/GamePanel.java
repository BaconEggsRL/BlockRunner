package tan.blockrunner;

import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Point;
import android.graphics.Rect;
import android.support.v7.app.AppCompatActivity;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;


public class GamePanel extends SurfaceView implements SurfaceHolder.Callback {
    private MainThread thread;

    private Player player;
    private Ground ground;
    private Obstacles obstacle;
    private int score = 0;
    private int time = 0;
    private long startTime = 0;
    private long endTime = 0;


    public GamePanel(Context context){
         super(context);

        //add the callback to the surfaceholder to intercept events
        getHolder().addCallback(this);

        thread = new MainThread(getHolder(), this);
        player = new Player(new Rect(100,400,200,Constants.FLOOR), Color.rgb(255,0,0));
        ground = new Ground(new Rect(0,Constants.FLOOR, Constants.SCREEN_WIDTH, Constants.SCREEN_HEIGHT), Color.rgb(0,0,0));
        obstacle = new Obstacles(new Rect(Constants.SCREEN_WIDTH,Constants.FLOOR-50,Constants.SCREEN_WIDTH+50,Constants.FLOOR), Color.rgb(0,255,0));
        startTime = System.currentTimeMillis();
        //make gamePanel focusable so it can handle events
        setFocusable(true);
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height){}

    @Override
    public void surfaceDestroyed(SurfaceHolder holder){
        boolean retry = true;
        while(retry)
        {
            try{thread.setRunning(false);
                thread.join();

            }catch(InterruptedException e){e.printStackTrace();}
            retry = false;
        }

    }

    @Override
    public void surfaceCreated(SurfaceHolder holder){

        //we can safely start the game loop
        thread.setRunning(true);
        thread.start();

    }
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getAction()){
            case MotionEvent.ACTION_DOWN:
                if(player.getRect().bottom == 500) {
                    player.getRect().set(player.getRect().left, player.getRect().top - 1,
                            player.getRect().right, player.getRect().bottom - 1);
                    player.vel -= 130;
                }
                break;
        }
        return true;

    }
    public void update() {
        if(player.playerCollide(obstacle)) {
            thread.setRunning(false);
            thread.interrupt();
            Intent GameOver = new Intent(this.getContext(),GameOverActivity.class);
            endTime = System.currentTimeMillis();
            time = (int) ((endTime-startTime)/1000);
            GameOver.putExtra("time", time+"");
            GameOver.putExtra("score", score+"");
            this.getContext().startActivity(GameOver);
        }
        player.update();
        ground.update();
        obstacle.update();

        //if(obstacle.)

        if(obstacle.getRect().right < 0){
            Obstacles obs = new Obstacles();
            obstacle = obs;
            score ++;
        }


    }
    @Override
    public void draw(Canvas canvas){
        super.draw(canvas);
        canvas.drawColor(Color.WHITE);
        player.draw(canvas);
        ground.draw(canvas);
        obstacle.draw(canvas);

    }
}