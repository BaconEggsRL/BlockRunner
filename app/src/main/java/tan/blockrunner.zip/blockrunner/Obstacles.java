package tan.blockrunner;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;

/**
 * Created by TAN on 11/19/2016.
 */

public class Obstacles implements GameObject {
    private Rect rectangle;
    private int color;
    private int vel;

    public Obstacles(Rect rectangle, int color) {
        this.color = color;
        this.rectangle = rectangle;
        vel = 20;
    }

    public Obstacles() {
        color = Color.GREEN;
        rectangle = new Rect(Constants.SCREEN_WIDTH, Constants.FLOOR - (int)(Math.random()*100+20),
                Constants.SCREEN_WIDTH + (int)(Math.random()*50+20), Constants.FLOOR);
        vel = (int)(20*Math.random()+20);
    }


    public Rect getRect(){
        return rectangle;
    }

    @Override
    public void draw(Canvas canvas) {
        Paint paint = new Paint();
        paint.setColor(color);
        canvas.drawRect(rectangle,paint);
    }

    @Override
    public void update() {
        rectangle.set(rectangle.left - vel, rectangle.top,
                rectangle.right - vel, rectangle.bottom);
    }
}
