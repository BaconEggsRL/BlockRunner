package tan.blockrunner;

/**
 * Created by TAN on 11/19/2016.
 */

public class Constants {
    public static int SCREEN_HEIGHT;
    public static int SCREEN_WIDTH;
    public static int ACCEL;
    public static int FLOOR;
}
